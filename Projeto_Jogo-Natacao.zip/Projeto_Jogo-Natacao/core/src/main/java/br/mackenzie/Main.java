package br.mackenzie;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */

/* Blue-Horizon -> Jogo de natação inclusivo
 * Criadores do Projeto:
 * Gabriel Labarca Del Bianco - 10443681
 * Gustavo Netto de Carvalho - 10437996
 * José Pedro Bitetti - 10427372
 * Vitor Costa Lemos - 10438932
 */

public class Main implements ApplicationListener {

    // Definindo Texturas
    // Textura Fundo
    Texture gameBackgroundTexture;

    // Efeito paralax no fundo
    float backgroundOffSetx = 0f; // Quanto o fundo vai deslocar no efeito paralax
    float paralaxVelocity = .75f;

    // Sprite Batch
    SpriteBatch spriteBatch;

    // Viewport
    FitViewport viewport;

    @Override
    public void create() {
        // Criando instâncias das texturas na memória
        gameBackgroundTexture = new Texture("Background-ParalaxOption2.jpeg");

        // Criando instância do spriteBatch
        spriteBatch = new SpriteBatch();

        // Aplicando o viewport de acordo com a tela
        viewport = new FitViewport(8,5);
    }

    @Override
    public void resize(int width, int height) {
        // Atualiza o viewport com o novo tamanho da janela
        viewport.update(width, height, true);

        // Resize your application here. The parameters represent the new window size.
    }

    @Override
    public void render() {
        input();
        logic();
        draw();
    }

    public void draw() {
        // Limpando a tela e ajustando a câmera
        ScreenUtils.clear(Color.BLACK);
        viewport.apply();
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);

        // Inserção das sprites
        spriteBatch.begin();

        // Pegando o tamanho da tela e armazenando em variáveis
        float worldWidth = viewport.getWorldWidth();
        float worldHeight = viewport.getWorldHeight();

        // Efeito paralax fundo
        float x1 = backgroundOffSetx % worldWidth;
        if (x1 > 0) x1 -= worldWidth;

        // Desenhando o fundo
        spriteBatch.draw(gameBackgroundTexture,x1,0, worldWidth,worldHeight);
        spriteBatch.draw(gameBackgroundTexture,x1+worldWidth,0, worldWidth,worldHeight);

        spriteBatch.end();
    }

    public void input() {
        float delta = Gdx.graphics.getDeltaTime();
        backgroundOffSetx -= delta*paralaxVelocity;
    }

    public void logic() { }

    @Override
    public void pause() {
        // Invoked when your application is paused.
    }

    @Override
    public void resume() {
        // Invoked when your application is resumed after pause.
    }

    @Override
    public void dispose() {
        spriteBatch.dispose();
        gameBackgroundTexture.dispose();
    }
}
